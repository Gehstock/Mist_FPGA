# Results

The testbench should approximately give the following step response results:

(leading zeroes are okay)
-    256
-    320
-    208
-    148
-    189
-    229
-    219
-    196
-    196
-    207
-    210
-    205
-    202
-    204
-    206
-    205
-    204
-    204
-    205
-    205
-    205
-    205
-    205
-    205
-    205
-    205
-    205

Note that may be a few +/- 1 round-off errors.
